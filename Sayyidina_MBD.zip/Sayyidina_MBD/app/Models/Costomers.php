<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Costomers extends Model
{
    use HasFactory;
    protected $fillable = [
       'CompanyName',
       'ContactName',
       'ContractTitle',
       'Address',
       'City',
       'Region',
       'PostalCode',
    ];
    public function orders()
    {
        return $this->hasMany(Orders::class);
    }
}
