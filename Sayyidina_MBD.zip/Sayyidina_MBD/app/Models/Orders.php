<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    use HasFactory;
    protected  $fillable = [
        'Costomers_id',
        'employees_id',
        'OrdeDate',
        'RequireDate',
        'ShippedDate',
        'shippers_id',
        'Freight',
        'ShipName',
        'ShipAddress',
        'ShipCity',
        'ShipRegion',
        'ShipPostalcode',
        'ShipCountry',
    ];
    public function costomers()
    {
        return $this->belongsTo(Costomers::class);
    }
    public function employees()
    {
        return $this->belongsTo(Employees::class);
    }
    public function shippers()
    {
        return $this->belongsTo(Shippers::class);
    }
    public function order_details()
    {
        return $this->hasMany(OrderDetails::class);
    }
}
