<?php

namespace Database\Factories;

use App\Models\Costomers;
use App\Models\Employees;
use App\Models\Shippers;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrdersFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $costomers = Costomers::pluck('id');
        $employeess = Employees::pluck('id');
        $ship = Shippers::pluck('id');
        return [
            'costomers_id' =>  $this->faker->randomElement($costomers),
            'employees_id' =>  $this->faker->randomElement($employeess),
            'OrdeDate' => $this->faker->date(),
            'RequireDate' => $this->faker->date(),
            'ShippedDate' => $this->faker->date(),
            'shippers_id' => $this->faker->randomElement($ship),
            'Freight' => $this->faker->randomFloat(2, 0, 100),
            'ShipName' => $this->faker->name(),
            'ShipAddress' => $this->faker->address(),
            'ShipCity' => $this->faker->city(),
            'ShipRegion' => $this->faker->state(),
            'ShipPostalCode' => $this->faker->postcode(),
            'ShipCountry' => $this->faker->country()

        ];
    }
}
