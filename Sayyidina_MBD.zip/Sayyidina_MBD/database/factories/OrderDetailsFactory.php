<?php

namespace Database\Factories;

use App\Models\Orders;
use App\Models\Products;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrderDetailsFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $product = Products::pluck('id');
        $orders = Orders::pluck('id');
        return [
            'products_id' =>  $this->faker->randomElement($product),
            'orders_id' =>  $this->faker->randomElement($orders),
            'UnitPrice' => $this->faker->randomFloat(2, 0, 100),
            'Quantity' => $this->faker->randomDigit(),
            'Discount' => $this->faker->randomFloat(2, 0, 50),
        ];
    }
}
