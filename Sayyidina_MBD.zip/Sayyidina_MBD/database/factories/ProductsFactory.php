<?php

namespace Database\Factories;

use App\Models\Categories;
use App\Models\Suppliers;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductsFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $suplier_id = Suppliers::pluck('id');
        $categories_id = Categories::pluck('id');
        return [
            'suppliers_id' =>  $this->faker->randomElement($suplier_id),
            'categories_id' =>  $this->faker->randomElement($categories_id),
            'ProductName' => $this->faker->name(),
            'QuantityPerUnit' => $this->faker->randomDigit(),
            'UnitPrice' => $this->faker->randomDigit(),
            'UnitsInStock' => $this->faker->randomDigit(),
            'UnitsOnOrder' => $this->faker->randomDigit(),
            'ReorderLevel' => $this->faker->randomDigit(),
            'Discontinued' => $this->faker->randomDigit(),
        ];
    }
}
