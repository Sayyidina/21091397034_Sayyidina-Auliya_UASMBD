<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ShippersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('shippers')->insert([
            'CompanyName' => 'JNT EXPRESS',
            'Phone' => '089849328948',
        ]);
        DB::table('shippers')->insert([
            'CompanyName' => 'JNE EXPRESS',
            'Phone' => '08984933424948',
        ]);
    }
}
