<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SuppliersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('suppliers')->insert([
            'CompanyName' => 'SayidinaPT',
            'ContactName' => 'Sayidina',
            'ContactTitle' => 'Dina',
            'Address' =>'Jalan Ketintang Baru',
            'City' => 'Surabaya',
            'Region' => 'Surabaya Region',
            'PostalCode' => '2342342'
        ]);
        DB::table('suppliers')->insert([
            'CompanyName' => 'DafidPT',
            'ContactName' => 'DafidJulianto',
            'ContactTitle' => 'Dafid',
            'Address' =>'Jalan Ketintang Lama',
            'City' => 'Surabaya',
            'Region' => 'Surabaya Region',
            'PostalCode' => '234234w'
        ]);
        DB::table('suppliers')->insert([
            'CompanyName' => 'RifqiPT',
            'ContactName' => 'Rifqihari',
            'ContactTitle' => 'Rifqi',
            'Address' =>'Jalan Ketintang Pusat',
            'City' => 'Surabaya',
            'Region' => 'Surabaya Region',
            'PostalCode' => '2342342sdas'
        ]);
        DB::table('suppliers')->insert([
            'CompanyName' => 'HariPT',
            'ContactName' => 'harios',
            'ContactTitle' => 'oir',
            'Address' =>'Bratang Perintis',
            'City' => 'Surabaya',
            'Region' => 'Surabaya Region',
            'PostalCode' => '2342342'
        ]);
        DB::table('suppliers')->insert([
            'CompanyName' => 'jauhaript',
            'ContactName' => 'jauhari',
            'ContactTitle' => 'jhari',
            'Address' =>'Jalan wonokromo',
            'City' => 'Surabaya',
            'Region' => 'Surabaya Region',
            'PostalCode' => '2342342wqeq'
        ]);
    }
}
