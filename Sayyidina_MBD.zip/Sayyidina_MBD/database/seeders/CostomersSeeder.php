<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CostomersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('costomers')->insert([
            'CompanyName' => 'Dina Bookstore',
            'ContactName' => 'Dina',
            'ContactTitle' => 'CEO',
            'Address' => 'Bratang Perintis',
            'City' => 'Surabaya',
            'Region' => 'Jawa Timur',
            'PostalCode' => '32432432'
        ]);
        DB::table('costomers')->insert([
            'CompanyName' => 'Dina boutique',
            'ContactName' => 'Dina',
            'ContactTitle' => 'CEO',
            'Address' => 'Bratang Perintis',
            'City' => 'Surabaya',
            'Region' => 'Jawa Timur',
            'PostalCode' => '32432432'
        ]);
        DB::table('costomers')->insert([
            'CompanyName' => 'Dina Restaurant',
            'ContactName' => 'Dina',
            'ContactTitle' => 'CEO',
            'Address' => 'Bratang Perintis',
            'City' => 'Surabaya',
            'Region' => 'Jawa Timur',
            'PostalCode' => '32432432'
        ]);
        DB::table('costomers')->insert([
            'CompanyName' => 'Fajar AGUNG',
            'ContactName' => 'Fajar',
            'ContactTitle' => 'CEO',
            'Address' => 'Kentintang Madya',
            'City' => 'Surabaya',
            'Region' => 'Jawa Timur',
            'PostalCode' => '32432432'
        ]);
        DB::table('costomers')->insert([
            'CompanyName' => 'Hario Software House',
            'ContactName' => 'Hario',
            'ContactTitle' => 'CEO',
            'Address' => 'Alam Pesona',
            'City' => 'Sidoarjo',
            'Region' => 'Jawa Timur',
            'PostalCode' => '32432432'
        ]);
    }
}
