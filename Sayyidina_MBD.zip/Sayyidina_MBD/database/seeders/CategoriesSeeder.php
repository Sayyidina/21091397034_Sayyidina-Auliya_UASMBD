<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            'CategoryName' => 'Tas Brandit',
            'Description' => 'Kategori Tas ini sangat disukai dalam lingkup lokal dan internasional',
            'picture' => 'https://source.unsplash.com/random',
        ]);
        DB::table('categories')->insert([
            'CategoryName' => 'Tas',
            'Description' => 'Kategori Tas ini sangat disukai dalam lingkup lokal dan internasional',
            'picture' => 'https://source.unsplash.com/random',
        ]); DB::table('categories')->insert([
            'CategoryName' => 'Sandal',
            'Description' => 'Kategori Sandal ini sangat disukai dalam lingkup lokal dan internasional',
            'picture' => 'https://source.unsplash.com/random',
        ]);
    }
}
