<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EmployeesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('Employees')->insert([
            'LastName' => 'Iqbal',
            'FirstName' => 'Hario',
            'Title' => 'CEO',
            'TitleOfCourtesy' => 'Tetap',
            'BirthDate' =>'2000-12-29',
            'HireDate' => '2021-01-01',
            'Address' => 'Bratang Perintis',
            'City' => 'Surabaya',
            'Region' => 'Jawa Timur'
        ]);
        DB::table('Employees')->insert([
            'LastName' => 'Ahmad',
            'FirstName' => 'Daniyal',
            'Title' => 'SS',
            'TitleOfCourtesy' => 'Tetap',
            'BirthDate' =>'2001-11-12',
            'HireDate' => '2021-06-01',
            'Address' => 'Probolinggo',
            'City' => 'Probolinggo',
            'Region' => 'Jawa Timur'
        ]);
        DB::table('Employees')->insert([
            'LastName' => 'Ahmad',
            'FirstName' => 'Daniyal',
            'Title' => 'SS',
            'TitleOfCourtesy' => 'Tetap',
            'BirthDate' =>'2001-06-12',
            'HireDate' => '2021-06-01',
            'Address' => 'Probolinggo',
            'City' => 'Probolinggo',
            'Region' => 'Jawa Timur'
        ]);
        DB::table('Employees')->insert([
            'LastName' => 'Ahmad',
            'FirstName' => 'Fikri',
            'Title' => 'Dapur',
            'TitleOfCourtesy' => 'Tetap',
            'BirthDate' =>'2002-04-12',
            'HireDate' => '2020-06-01',
            'Address' => 'Probolinggo',
            'City' => 'Probolinggo',
            'Region' => 'Jawa Timur'
        ]);
        DB::table('Employees')->insert([
            'LastName' => 'Lional',
            'FirstName' => 'Messi',
            'Title' => 'Kurir',
            'TitleOfCourtesy' => 'Tetap',
            'BirthDate' =>'2002-01-11',
            'HireDate' => '2021-06-01',
            'Address' => 'jalan ngalek',
            'City' => 'Tranggalek',
            'Region' => 'Jawa Timur'
        ]);
    }
}
