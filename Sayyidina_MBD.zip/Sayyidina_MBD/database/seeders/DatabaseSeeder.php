<?php

namespace Database\Seeders;

use App\Models\Employees;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */

    public function run()
    {
        $this->call(
            [
                SuppliersSeeder::class
            ]
        );
        $this->call(
            [
                CategoriesSeeder::class
            ]
        );
        $this->call(
            [
                EmployeesSeeder::class
            ]
        );
        $this->call(
            [
                CostomersSeeder::class
            ]
        );
        $this->call(
            [
                ShippersSeeder::class
            ]
        );
        // \App\Models\User::factory(10)->create();
         \App\Models\Products::factory(10)->create();
         \App\Models\Orders::factory(5)->create();
         \App\Models\OrderDetails::factory(20)->create();
    }
}
